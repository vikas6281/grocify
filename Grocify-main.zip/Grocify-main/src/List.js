
let list= [
    {
      name:"Pineapple",
      imgUrl:"./S1.jpg",
      category:"fruit",
      text:"1kg",
      price:200,
      stock:5,


    },{
      name:"Avocado",
      imgUrl:"./S2.jpg",
      category:"fruit",
      text:"1kg",
      price:350,
      stock:5,

    },{
      name:"Papaya",
      imgUrl:"./S3.jpg",
      category:"fruit",
      text:"1kg",
      price:100,
      stock:5,

    },{
      name:"Apple",
      imgUrl:"./S4.jpg",
      category:"fruit",
      text:"3kg",
      price:100,
      stock:5,

    },{
      name:"Kevin",
      imgUrl:"./S5.jpg",
      category:"fruit",
      text:"1kg",
      price:500,
      stock:5,

    },{
      name:"Orange",
      imgUrl:"./S6.jpg",
      category:"fruit",
      text:"1kg",
      price:90,
      stock:5,

    },{
      name:"Pear",
      imgUrl:"./S7.jpg",
      category:"fruit",
      text:"1kg",
      price:100,
      stock:5,

    },{
      name:"Strawberry",
      imgUrl:"./S8.jpg",
      category:"fruit",
      text:"1kg",
      price:200,
      stock:5,

    },

    
    {
      name:"Butter",
      imgUrl:"./Butter.jpg",
      category:"Dairy",
      text:"100gm",
      price:80,
      stock:5,

    },
     {
      name:"Cheese",
      imgUrl:"./cheese.jpg",
      category:"Dairy",
      text:"100gm",
      price:100,
      stock:5,

    },
    {
      name:"Milk",
      imgUrl:"./Milk.jpg",
      category:"Dairy",
      text:"1lt",
      price:30,
      stock:5,

    },
    {
      name:"Yogurt",
      imgUrl:"./Yogurt.jpg",
      category:"Dairy",
      text:"1kg",
      price:180,
      stock:5,

    },



    {
      name:"Tomatoes",
      imgUrl:"./Tomatoes.jpg",
      category:"Vegetables",
      text:"1kg",
      price:60,
      stock:5,

    },{
      name:"Beets",
      imgUrl:"./Beets.jpg",
      category:"Vegetables",
      text:"1kg",
      price:50,
      stock:5,

    },{
      name:"Broccoli",
      imgUrl:"./Broccoli.jpg",
      category:"Vegetables",
      text:"1kg",
      price:90,
      stock:5,

    },{
      name:"Cabbage",
      imgUrl:"./Cabbage.jpg",
      category:"Vegetables",
      text:"1kg",
      price:80,
      stock:5,

    },{
      name:"Cauliflower",
      imgUrl:"./Cauliflower.jpg",
      category:"Vegetables",
      text:"1kg",
      price:30,
      stock:5,

    },{
      name:"Garlic",
      imgUrl:"./Garlic.jpg",
      category:"Vegetables",
      text:"500gm",
      price:100,
      stock:5,

    },{
      name:"Onions",
      imgUrl:"./Onions.jpg",
      category:"Vegetables",
      text:"1kg",
      price:70,
      stock:5,

    },{
      name:"Potatoes",
      imgUrl:"./Potatoes.jpg",
      category:"Vegetables",
      text:"1kg",
      price:100,
      stock:5,

    },





    {
      name:"Popcorn",
      imgUrl:"./Popcorn.jpg",
      category:"Snacks",
      text:"100gm",
      price:30,
      stock:5,

    },{
      name:"Almonds",
      imgUrl:"./Almonds.jpg",
      category:"Snacks",
      text:"1kg",
      price:500,
      stock:5,

    },{
      name:"Candy",
      imgUrl:"./Candy.jpg",
      category:"Snacks",
      text:"1kg",
      price:500,
      stock:5,

    },{
      name:"Cookies",
      imgUrl:"./Cookies.jpg",
      category:"Snacks",
      text:"300gm",
      price:30,
      stock:5,

    },



    {
      name:"Sponges",
      imgUrl:"./Sponges.jpg",
      category:"Household",
      text:"1kg",
      price:80,
      stock:5,

    },{
      name:"Batteries",
      imgUrl:"./Batteries.jpg",
      category:"Household",
      text:"1PAck",
      price:30,
      stock:5,

    },{
      name:"soap",
      imgUrl:"./soap.jpg",
      category:"Household",
      text:"1kg",
      price:100,
      stock:5,

    },{
      name:"Napkins",
      imgUrl:"./Napkins.jpg",
      category:"Household",
      text:"1box",
      price:20,
      stock:5,

    },
    {
      name:"conditioner",
      imgUrl:"./conditioner.jpg",
      category:"Household",
      text:"1lt",
      price:200,
      stock:8,

    },
    {
      name:"Shampoo",
      imgUrl:"./Shampoo.jpg",
      category:"Household",
      text:"1lt",
      price:150,
      stock:7,

    }









  ]

  export default list